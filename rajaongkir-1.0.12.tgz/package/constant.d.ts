export declare const starterBaseUrl: string;
export declare const basicBaseUrl: string;
export declare const proBaseUrl: string;
export declare const apiType: string;
export declare const apiKey: string;
export declare enum TypeOption {
    STARTER = "starter",
    BASIC = "basic",
    PRO = "pro"
}
