export default class RajaOngkir {
    private apiType;
    private apiKey;
    constructor(apiType: string, apiKey: string);
    getKey(): string;
    getBaseUrl(): string;
}
