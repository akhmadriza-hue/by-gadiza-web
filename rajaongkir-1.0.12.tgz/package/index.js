"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const constant_1 = require("./constant");
class RajaOngkir {
    constructor(apiType, apiKey) {
        this.apiType = apiType;
        this.apiKey = apiKey;
    }
    getKey() {
        return this.apiKey;
    }
    getBaseUrl() {
        switch (this.apiType) {
            case constant_1.TypeOption.BASIC:
                return constant_1.basicBaseUrl;
                break;
            case constant_1.TypeOption.PRO:
                return constant_1.proBaseUrl;
                break;
            case constant_1.TypeOption.STARTER:
                return constant_1.starterBaseUrl;
                break;
            default:
                throw new Error('undefined API_TYPE');
                break;
        }
    }
}
exports.default = RajaOngkir;
