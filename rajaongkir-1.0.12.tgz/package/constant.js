"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypeOption = exports.apiKey = exports.apiType = exports.proBaseUrl = exports.basicBaseUrl = exports.starterBaseUrl = void 0;
exports.starterBaseUrl = process.env.RAJAONGKIR_API_STARTER_BASE_URL || 'https://api.rajaongkir.com/starter';
exports.basicBaseUrl = process.env.RAJAONGKIR_API_BASIC_BASE_URL || 'https://api.rajaongkir.com/basic';
exports.proBaseUrl = process.env.RAJAONGKIR_API_PRO_BASE_URL || 'https://pro.rajaongkir.com/api';
exports.apiType = process.env.RAJAONGKIR_API_TYPE || 'starter';
exports.apiKey = process.env.RAJAONGKIR_API_KEY || '';
var TypeOption;
(function (TypeOption) {
    TypeOption["STARTER"] = "starter";
    TypeOption["BASIC"] = "basic";
    TypeOption["PRO"] = "pro";
})(TypeOption || (exports.TypeOption = TypeOption = {}));
