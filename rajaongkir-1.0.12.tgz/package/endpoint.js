"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCost = exports.getSubDistrict = exports.getCity = exports.getProvince = exports.rajaongkir = void 0;
const _1 = __importDefault(require("."));
const constant_1 = require("./constant");
exports.rajaongkir = new _1.default(constant_1.apiType, constant_1.apiKey);
const getProvince = (req) => __awaiter(void 0, void 0, void 0, function* () {
    const res = yield fetch(`${exports.rajaongkir.getBaseUrl()}/province?${new URLSearchParams(req).toString()}`, { headers: { 'key': exports.rajaongkir.getKey() } });
    return res.json();
});
exports.getProvince = getProvince;
const getCity = (req) => __awaiter(void 0, void 0, void 0, function* () {
    const res = yield fetch(`${exports.rajaongkir.getBaseUrl()}/city?${new URLSearchParams(req).toString()}`, { headers: { 'key': exports.rajaongkir.getKey() } });
    return res.json();
});
exports.getCity = getCity;
const getSubDistrict = (req) => __awaiter(void 0, void 0, void 0, function* () {
    const res = yield fetch(`${exports.rajaongkir.getBaseUrl()}/subdistrict?${new URLSearchParams(req).toString()}`, { headers: { 'key': exports.rajaongkir.getKey() } });
    return res.json();
});
exports.getSubDistrict = getSubDistrict;
const getCost = (req) => __awaiter(void 0, void 0, void 0, function* () {
    const res = yield fetch(`${exports.rajaongkir.getBaseUrl()}/cost`, {
        method: 'POST',
        headers: {
            'key': exports.rajaongkir.getKey(),
            'content-type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams(req)
    });
    return res.json();
});
exports.getCost = getCost;
