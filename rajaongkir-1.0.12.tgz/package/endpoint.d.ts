import RajaOngkir from ".";
import { getCityResponse, getCostRequest, getCostResponse, getProvinceResponse, getSubDistrictResponse } from "./dto";
export declare const rajaongkir: RajaOngkir;
export declare const getProvince: (req?: {
    id?: string;
}) => Promise<getProvinceResponse>;
export declare const getCity: (req?: {
    id?: string;
    province?: string;
}) => Promise<getCityResponse>;
export declare const getSubDistrict: (req?: {
    id?: string;
    city?: string;
}) => Promise<getSubDistrictResponse>;
export declare const getCost: (req: getCostRequest) => Promise<getCostResponse>;
