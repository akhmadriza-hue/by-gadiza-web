"use strict";

var database;
var connect       = require('camo').connect;
var dataPath      = __dirname + '/data';
var uriConnection = 'nedb://' + dataPath;
var Province      = require('./models/Province');
var City          = require('./models/City');
var slug          = require('slug');
var _             = require('underscore');
var async         = require('async');


var province  = 'Yogyakarta';
var data = 'Kabupaten Bantul/Kabupaten Gunungkidul/Kabupaten Kulon Progo/Kabupaten Sleman/Kota Yogyakarta'
parse(province, data);

function parse(province, data)
{
  connect(uriConnection).then(function(db) {
    database = db;
    Province.findOne({name: province}).then(function(p) {
      var fix = [];
      data    = data.split('/');

      async.eachOf(data, function(value, key, cb) {
        var insert  = { name: value, province: p._id };
        var city    = City.create(insert);

        city.save().then(function(l) {
          console.log('> ' + l.name);
          cb();
        }).catch(err => {
          console.log('Error:', err);
        });
      }, function(err){
        console.log('----------------------> Done')
      });
    }, function(err) {
      console.log('Error:', err);
    });
  });
}
