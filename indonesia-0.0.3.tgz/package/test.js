const indonesia = require('.');

indonesia.searchProvince('a', function(provinces){
  console.log(provinces)
});
